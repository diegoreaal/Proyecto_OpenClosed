public interface Notificador {
    void enviar(String destinatario, String mensaje);
}